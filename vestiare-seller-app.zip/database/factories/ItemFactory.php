<?php

namespace Database\Factories;

use App\Enums\PayoutStatusEnum;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Item>
 */
class ItemFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $user = User::inRandomOrder()->first();

        return [
            'name' => $this->faker->words(2, true) . ' ' . $this->faker->randomElement([
                    'Handbag', 'Watch', 'Jewelry', 'Sneakers', 'Sunglasses', 'Coat'
                ]),
            'price_amount' => $this->faker->randomFloat(2, 100, 10000),
            'price_currency' => $user->currency,
            'status' => $this->faker->randomElement([
                    PayoutStatusEnum::PENDING->value,
            ]),
            'user_id' => $user->id,
        ];
    }
}
