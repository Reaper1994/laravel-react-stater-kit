<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Item;
use App\Models\User;
use Illuminate\Database\Seeder;

class ItemsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = User::all();

        // Seed 50 items, randomly assigning to one of the users
        Item::factory()->count(20)->make()->each(function ($item) use ($users) {
            $item->user_id = $users->random()->id;
            $item->save();
        });
    }
}
