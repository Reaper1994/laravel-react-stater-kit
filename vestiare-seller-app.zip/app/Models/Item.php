<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'price_amount',
        'price_currency',
        'user_id',
        'status',
    ];

    protected $casts = [
        'price_amount' => 'float',
    ];

    /**
     * Get the user that owns the item.
     */
    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the payouts associated with the item.
     */
    public function payouts(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    {
        return $this->belongsToMany(Payout::class, 'item_payouts', 'item_id', 'payout_id')
            ->withTimestamps();
    }
}
