<?php

namespace App\Observers;

use App\Enums\PayoutStatusEnum;
use App\Models\Item;
use App\Models\ItemPayout;
use App\Models\Payout;
use JetBrains\PhpStorm\NoReturn;

class PayoutObserver
{
    /**
     * Handle the Payout "created" event.
     *
     * @param  \App\Models\Payout  $payout
     * @return void
     */
    #[NoReturn]
    public function created(Payout $payout): void
    {

        \DB::afterCommit(function () use ($payout) {
            $itemIds = ItemPayout::where('payout_id', $payout->id)
                ->pluck('item_id');

            if ($itemIds->isEmpty()) {
                \Log::warning("No items found for payout ID: {$payout->id}");
            } else {
                Item::whereIn('id', $itemIds->toArray())
                    ->update(['status' => PayoutStatusEnum::COMPLETED->value]);
            }
        });
    }
}
