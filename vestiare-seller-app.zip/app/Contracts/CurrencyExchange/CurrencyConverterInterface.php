<?php
declare(strict_types=1);

namespace App\Contracts\CurrencyExchange;

interface CurrencyConverterInterface
{
    /**
     * Convert an amount from one currency to another.
     *
     * @param float $amount
     * @param string $fromCurrency
     * @param string $toCurrency
     * @return float
     */
    public function convert(float $amount, string $fromCurrency, string $toCurrency): float;
}
