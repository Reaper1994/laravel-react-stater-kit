<?php

declare(strict_types=1);

namespace App\Contracts\Payout;

use App\Models\Payout;

use App\DTO\PayoutDTO;

interface PayoutServiceInterface
{
    /**
     * Create payouts for the given items.
     *
     * @param PayoutDTO $payoutDTO
     * @return array
     */
    public function createPayouts(PayoutDTO $payoutDTO): array;
}
