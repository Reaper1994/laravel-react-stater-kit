<?php

declare(strict_types=1);

namespace App\Contracts\Commission;

interface CommissionCalculatorInterface
{
    /**
     * Calculate the commission for a given amount.
     *
     * @param float $amount
     * @return float The commission amount
     */
    public function calculateCommission(float $amount): float;
}
