<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Contracts\Payout\PayoutServiceInterface;
use App\Http\Controllers\Controller;
use App\DTO\PayoutDTO;
use App\Http\Resources\PayoutResource;
use Illuminate\Http\Request;

class PayoutController extends Controller
{
    protected PayoutServiceInterface $payoutService;

    public function __construct(PayoutServiceInterface $payoutService)
    {
        $this->payoutService = $payoutService;
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function createPayouts(Request $request): \Illuminate\Http\JsonResponse
    {
        $validated = $request->validate([
            'items' => 'required|array',
        ]);

        $payoutDTO = PayoutDTO::fromRequest($validated);

        // Create payouts and get the resulting payouts
        $createdPayouts = $this->payoutService->createPayouts($payoutDTO);

        // Return the created payouts as resources
        return response()->json([
            'message' => 'Payouts created successfully.',
            'data' => PayoutResource::collection($createdPayouts),
        ]);
    }
}
