<?php

namespace App\Providers;

use App\Contracts\Commission\CommissionCalculatorInterface;
use App\Contracts\CurrencyExchange\CurrencyConverterInterface;
use App\Contracts\Payout\PayoutServiceInterface;
use App\Models\Payout;
use App\Observers\PayoutObserver;
use App\Services\Commission\CommissionCalculator;
use App\Services\Converter\CurrencyConverter;
use App\Services\Payout\PayoutService;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
        $this->app->bind(CurrencyConverterInterface::class, CurrencyConverter::class);
        $this->app->bind(PayoutServiceInterface::class, PayoutService::class);
        $this->app->bind(CommissionCalculatorInterface::class, CommissionCalculator::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
        Payout::observe(PayoutObserver::class);
    }
}
