<?php
declare(strict_types=1);

namespace App\DTO;

use http\Exception\InvalidArgumentException;

readonly class PayoutDTO
{
    /**
     * @param array<int, int> $items Array of item IDs
     */
    public function __construct(
        public array $items
    ) {}

    /**
     * Create a new PayoutDTO from an array of data.
     *
     * @param array<string, mixed> $data
     * @return self
     */
    public static function fromRequest(array $data): self
    {
        return new self(
            $data['items']
        );
    }
}
