<?php

declare(strict_types=1);

namespace App\Services\Commission;

use App\Contracts\Commission\CommissionCalculatorInterface;

class CommissionCalculator implements CommissionCalculatorInterface
{
    protected float $commissionRate;

    public function __construct()
    {
        $this->commissionRate = 0.05;
    }

    public function calculateCommission(float $amount): float
    {
        return $amount * $this->commissionRate;
    }
}
