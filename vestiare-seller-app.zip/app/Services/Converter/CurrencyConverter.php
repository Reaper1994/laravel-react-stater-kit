<?php

declare(strict_types=1);

namespace App\Services\Converter;

use App\Contracts\CurrencyExchange\CurrencyConverterInterface;

/**
 *
 */
final class CurrencyConverter implements CurrencyConverterInterface
{
    /**
     * Dummy Currency converter.
     *
     * @param float $amount
     * @param string $fromCurrency
     * @param string $toCurrency
     * @return float
     *
     * @throws \Exception
     */
    public function convert(float $amount, string $fromCurrency, string $toCurrency): float
    {
        if ($fromCurrency === $toCurrency) {
            return $amount;
        }

        $exchangeRates = [
            'GBP' => 1.0,
            'USD' => 0.85,
            'EUR' => 0.75,
        ];

        if (!isset($exchangeRates[$fromCurrency]) || !isset($exchangeRates[$toCurrency])) {
            throw new \Exception("Unsupported currency conversion.");
        }

        $baseAmount = $amount / $exchangeRates[$fromCurrency];
        return $baseAmount * $exchangeRates[$toCurrency];
    }
}
