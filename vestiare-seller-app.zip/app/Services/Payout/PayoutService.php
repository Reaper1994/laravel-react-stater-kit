<?php
declare(strict_types=1);

namespace App\Services\Payout;

use App\Contracts\Commission\CommissionCalculatorInterface;
use App\Contracts\CurrencyExchange\CurrencyConverterInterface;
use App\Contracts\Payout\PayoutServiceInterface;
use App\DTO\PayoutDTO;
use App\Enums\PayoutStatusEnum;
use App\Models\Item;
use App\Models\Payout;
use Illuminate\Support\Facades\DB;

final class PayoutService implements PayoutServiceInterface
{
    protected CurrencyConverterInterface $currencyConverter;
    protected CommissionCalculatorInterface $commissionCalculator;
    protected int $payoutLimit;

    public function __construct(
        CurrencyConverterInterface $currencyConverter,
        CommissionCalculatorInterface $commissionCalculator
    ){
        $this->currencyConverter = $currencyConverter;
        $this->commissionCalculator = $commissionCalculator;
        $this->payoutLimit = config('vestiare-config.payout_limit');
    }


    /**
     * @param PayoutDTO $payoutDTO
     * @return array
     * @throws \Exception
     */
    public function createPayouts(PayoutDTO $payoutDTO): array
    {
        DB::beginTransaction();

        try {
            $createdPayouts = [];

            $groupedItems = [];
            foreach ($payoutDTO->items as $itemId) {
                $item = Item::findOrFail($itemId);

                if ($item->status === PayoutStatusEnum::COMPLETED->value) {
                    continue;
                }

                $user = $item->user;
                $preferredCurrency = $user->currency;

                if (!isset($groupedItems[$user->id])) {
                    $groupedItems[$user->id] = [
                        'items' => [],
                        'total_amount' => 0,
                        'currency' => $preferredCurrency,
                        'commission' => 0,
                    ];
                }

                $totalAmount = $item->price_amount;
                $convertedAmount = $this->currencyConverter->convert(
                    $totalAmount,
                    $item->price_currency,
                    $preferredCurrency
                );


                $commission = $this->commissionCalculator->calculateCommission($convertedAmount);
                $netAmount = $convertedAmount - $commission;

                $groupedItems[$user->id]['items'][] = $item;
                $groupedItems[$user->id]['total_amount'] += $netAmount;
                $groupedItems[$user->id]['commission'] += $commission;
            }

            // Create payouts for each user
            foreach ($groupedItems as $userId => $data) {
                $batchAmounts = $this->splitPayoutAmount($data['total_amount']);
                $payoutIds = [];

                foreach ($batchAmounts as $amount) {
                    $payout = Payout::create([
                        'user_id' => $userId,
                        'amount' => $amount,
                        'currency' => $data['currency'],
                        'status' => PayoutStatusEnum::INITIATED,
                        'commission' => $data['commission'],
                    ]);

                    $createdPayouts[] = $payout;
                    $payoutIds[] = $payout->id;
                }

                // Links all items to the created payouts
                foreach ($data['items'] as $item) {
                    $item->payouts()->syncWithoutDetaching($payoutIds);
                }
            }

            DB::commit();

            return $createdPayouts;
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    private function splitPayoutAmount(float $amount): array
    {
        $batches = [];
        while ($amount > $this->payoutLimit) {
            $batches[] = $this->payoutLimit;
            $amount -= $this->payoutLimit;
        }
        $batches[] = $amount;
        return $batches;
    }
}
