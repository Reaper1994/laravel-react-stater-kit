# Vestiare seller payout api  V1

## Description

API endpoint that accepts a list of sold Items and creates Payouts for the sellers.
## Requirements

- PHP >= 8.3
- Composer
- Laravel >= 11
- Database (e.g., MySQL)

## Installation

1. **Create a .env File**

   Refer to the example file to create your `.env` file:

   ```bash
   cp .env.example .env
   ```

## Generate Application Key

Run the following command to generate an application key:

``` bash
php artisan key:generate
```

## Update the .env File

Open the .env file and update the database configurations according to your setup.

## Run Migrations and Seed the Database

Execute the following command to migrate the database and seed it with initial data:

```bash
php artisan migrate:fresh --seed
```

##  Install Dependencies

Run the following command to install the necessary PHP dependencies:

```bash
composer install
```

## Configure Payout Limit

The payout limit can be configured in the .env file. Just add the following variable at the end of the file:

``` bash
PAYOUT_LIMIT=<your limit>
```

## Usage

``` bash
curl -X POST {{ base url}}/api/v1/payouts \ 
-H "Content-Type: application/json" \
-d '{
    "items": [1, 2]
}'

```
Here 1 and 2 are the item ids.


When the payout creation is successful, the API returns the following JSON response:

```json
{
  "message": "Payouts created successfully.",
  "data": [
    {
      "id": 2,
      "user_id": 1,
      "amount": 8414.454,
      "currency": "GBP",
      "status": "completed",
      "created_at": "2024-10-21T23:22:37.000000Z",
      "updated_at": "2024-10-21T23:22:37.000000Z"
    }
  ]
}
```


## Run testcases

``` bash
./vendor/bin/pest --coverage
```







