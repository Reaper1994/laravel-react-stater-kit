<?php

return [
    'payout_limit' => env('PAYOUT_LIMIT', 1000000),
];
