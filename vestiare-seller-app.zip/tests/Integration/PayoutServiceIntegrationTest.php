<?php

declare(strict_types=1);

use App\Models\User;
use App\Models\Item;
use App\Services\Payout\PayoutService;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

it('creates payouts with commission deduction', function () {
    $user = User::factory()->create(['currency' => 'USD']);
    $items = Item::factory()->count(2)->create([
        'user_id' => $user->id,
        'price_currency' => 'USD',
        'price_amount' => 500,
    ]);

    $payoutService = app(PayoutService::class);
    $payouts = $payoutService->createPayouts($items->toArray());

    $totalAmount = array_sum(array_column($payouts, 'amount'));
    expect($totalAmount)->toBeLessThan(1000);
});
