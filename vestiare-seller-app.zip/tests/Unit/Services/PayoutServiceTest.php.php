<?php

declare(strict_types=1);

use App\Contracts\Commission\CommissionCalculatorInterface;
use App\Contracts\CurrencyExchange\CurrencyConverterInterface;
use App\Enums\PayoutStatusEnum;
use App\Models\Payout;
use App\Models\User;
use App\Models\Item;
use App\Services\Payout\PayoutService;
use App\DTO\PayoutDTO;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;

uses(RefreshDatabase::class);

beforeEach(function () {
    $this->payoutService = app(PayoutService::class);
});

it('splits payouts correctly based on limit', function () {
    $user = User::factory()->create(['currency' => 'USD']);
    $items = Item::factory()->count(3)->create([
        'user_id' => $user->id,
        'price_currency' => 'USD',
        'price_amount' => 600000,
    ]);

    $payouts = $this->payoutService->createPayouts(new PayoutDTO(items: $items->pluck('id')->toArray()));

    expect(count($payouts))->toBeGreaterThan(1); // Multiple payouts
});


it('updates item status to COMPLETED after payout creation', function () {
    $user = User::factory()->create(['currency' => 'USD']);
    $items = Item::factory()->count(3)->create([
        'user_id' => $user->id,
        'status' => PayoutStatusEnum::PENDING->value,
        'price_currency' => 'USD',
        'price_amount' => 500000,
    ]);

    $payoutDTO = new PayoutDTO(items: $items->pluck('id')->toArray());
    $this->payoutService->createPayouts($payoutDTO);

    // Check if item statuses have been updated
    foreach ($items as $item) {
        $item->refresh();
        expect($item->status)->toBe(PayoutStatusEnum::COMPLETED->value);
    }
});

it('throws an exception for invalid data', function () {
    $this->expectException(\InvalidArgumentException::class);

    // Passing an empty array to simulate invalid data
    $this->payoutService->createPayouts(new PayoutDTO(items: []));
});

it('rolls back transaction on failure', function () {
    DB::shouldReceive('beginTransaction')->once();
    DB::shouldReceive('rollBack')->once();

    $this->expectException(\Exception::class);

    $payoutDTO = new PayoutDTO(items: [99999]);
    $this->payoutService->createPayouts($payoutDTO);
});

it('does not create payouts for already completed items', function () {
    $user = User::factory()->create(['currency' => 'USD']);
    $items = Item::factory()->count(3)->create([
        'user_id' => $user->id,
        'price_currency' => 'USD',
        'price_amount' => 600000,
        'status' => PayoutStatusEnum::COMPLETED->value,
    ]);

    $payoutDTO = new PayoutDTO(items: $items->pluck('id')->toArray());
    $payouts = $this->payoutService->createPayouts($payoutDTO);

    // Expect no payouts to be created
    expect($payouts)->toBeEmpty();
});

it('correctly splits payout amounts into batches', function () {
    $payouts = $this->payoutService->splitPayoutAmount(2500000);
    expect($payouts)->toBe([1000000, 1000000, 500000]);
});

it('rolls back transaction on invalid item ID', function () {
    DB::shouldReceive('beginTransaction')->once();
    DB::shouldReceive('rollBack')->once();

    $user = User::factory()->create(['currency' => 'USD']);
    $items = Item::factory()->count(3)->create([
        'user_id' => $user->id,
        'price_currency' => 'USD',
        'price_amount' => 100,
    ]);

    $invalidItemId = 99999;

    $this->expectException(\Illuminate\Database\Eloquent\ModelNotFoundException::class);

    $this->payoutService->createPayouts(
        new PayoutDTO(
            items: [...$items->pluck('id')->toArray(),
            $invalidItemId])
    );
});

it('skips payout creation if item status is completed', function () {
    DB::shouldReceive('beginTransaction')->once();
    DB::shouldReceive('rollBack')->once();

    $user = User::factory()->create(['currency' => 'USD']);
    // Create a user and items with a completed status
    $user = User::factory()->create(['currency' => 'USD']);
    $items = Item::factory()->count(3)->create([
        'user_id' => $user->id,
        'price_currency' => 'USD',
        'price_amount' => 100,
        'status' => PayoutStatusEnum::COMPLETED->value,
    ]);

    // Call createPayouts with the completed items
    $createdPayouts = $this->payoutService->createPayouts(new PayoutDTO(items: $items->pluck('id')->toArray()));

    expect($createdPayouts)->toBeEmpty();
});

it('creates payouts for a single user with multiple items', function () {

    $user = User::factory()->create();
    $item1 = Item::factory()->create(['user_id' => $user->id, 'price_amount' => 500, 'price_currency' => 'USD']);
    $item2 = Item::factory()->create(['user_id' => $user->id, 'price_amount' => 700, 'price_currency' => 'USD']);
    $payoutDTO = new PayoutDTO(items: [$item1->id, $item2->id]);

    $currencyConverterMock = Mockery::mock(CurrencyConverterInterface::class);
    $currencyConverterMock->shouldReceive('convert')->andReturnUsing(function ($amount, $fromCurrency, $toCurrency) {
        return $amount;
    });

    $commissionCalculatorMock = Mockery::mock(CommissionCalculatorInterface::class);
    $commissionCalculatorMock->shouldReceive('calculateCommission')->andReturn(50); // Fixed commission for simplicity

    $payoutService = new PayoutService($currencyConverterMock, $commissionCalculatorMock);

    $createdPayouts = $payoutService->createPayouts($payoutDTO);

    expect($createdPayouts)->toHaveCount(1)
        ->and($createdPayouts[0]->amount)->toEqual(1150)
        ->and($item1->payouts)->toHaveCount(1)
        ->and($item2->payouts)->toHaveCount(1);
});
