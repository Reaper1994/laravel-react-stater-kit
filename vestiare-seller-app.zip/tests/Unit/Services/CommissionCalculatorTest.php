<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Services\Commission\CommissionCalculator;


it('calculates commission correctly', function () {
    $calculator = new CommissionCalculator();
    $amount = 1000;

    $expectedCommission = $amount * 0.05;

    // Assert that the calculated commission matches the expected value
    expect($calculator->calculateCommission($amount))->toEqual($expectedCommission);
});
