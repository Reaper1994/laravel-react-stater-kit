<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

 // Adjust the namespace based on your service location
 use App\Services\Converter\CurrencyConverter;
 use Tests\TestCase;

beforeEach(function () {
    // This ensures the Laravel application is booted
});

it('converts GBP to GBP correctly', function () {
    $converter = new CurrencyConverter();
    $amount = 100;

    $convertedAmount = $converter->convert($amount, 'GBP', 'GBP');

    expect($convertedAmount)->toEqual($amount);
});

 it('exception thrown on submitting unsupported currency', function () {
     $converter = new CurrencyConverter();
     $this->expectException(\Exception::class);
     $this->expectExceptionMessage("Unsupported currency conversion.");

     $converter->convert(100, 'GBP', 'INR');
 });

 it('returns the same amount when converting the same currency', function () {
     $converter = new CurrencyConverter();
     $amount = 1000.00;
     $currency = 'USD';

     $convertedAmount = $converter->convert($amount, $currency, $currency);

     expect($convertedAmount)->toEqual($amount);
 });

 it('converts GBP to USD correctly', function () {
     $converter = new CurrencyConverter();
     $amount = 1000.00;
     $fromCurrency = 'GBP';
     $toCurrency = 'USD';

     $convertedAmount = $converter->convert($amount, $fromCurrency, $toCurrency);

     // GBP to USD conversion
     // 1000 GBP * 0.85 (USD rate) = 850.00
     expect($convertedAmount)->toEqual(850.00);
 });
