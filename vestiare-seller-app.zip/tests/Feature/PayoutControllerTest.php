<?php
declare(strict_types=1);

use App\Models\User;
use App\Models\Item;
use Symfony\Component\HttpFoundation\Response;
use function Pest\Laravel\postJson;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

beforeEach(function () {
    $this->actingAs(User::factory()->create(), 'sanctum');
});

it('returns 201 on valid payout creation', function () {
    $user = User::factory()->create(['currency' => 'USD']);
    $items = Item::factory()->count(2)->create([
        'user_id' => $user->id,
        'price_currency' => 'USD',
        'price_amount' => 500,
    ])->toArray();


    $item_ids = array_column($items, 'id');

    $response = postJson('/api/v1/payouts', ['items' => $item_ids]);

    $response->assertStatus(200)
        ->assertJson(['message' => 'Payouts created successfully.']);
});

